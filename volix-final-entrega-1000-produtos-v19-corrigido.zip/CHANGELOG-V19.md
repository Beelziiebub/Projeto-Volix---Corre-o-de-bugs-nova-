# Changelog V19

## Correção do parser JSON
- Corrigido o tratamento de strings JSON com aspas escapadas em `backend/src/scraper.js`.
- O parser agora converte corretamente `Produto \"Especial\"` em `Produto "Especial"`.
- Mantidos os testes anteriores de metadados, IDs, preços e bloqueios.

## Documentação
- README atualizado para a versão 2.5.0 (V19).

## Segurança
- Mantidas as dependências corrigidas da V18.
- O projeto foi preparado para `npm audit` sem vulnerabilidades conforme a validação anterior.
