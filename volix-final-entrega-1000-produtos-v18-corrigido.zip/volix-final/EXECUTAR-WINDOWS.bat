@echo off
setlocal
cd /d "%~dp0"

if exist "%~dp0Volix.exe" (
    start "" "%~dp0Volix.exe"
    exit /b 0
)

rem Fallback para execucao sem o launcher compilado.
cmd /k call "%~dp0EXECUTAR-WINDOWS-INTERNO.bat"
