# Launcher Windows — Volix.exe

O `Volix.exe` e um launcher grafico para Windows. Ele nao abre PowerShell nem uma janela de CMD para o usuario.

## Requisito

- Windows 10/11 x64
- Node.js 20 ou superior instalado
- Internet para o `npm install` na primeira execucao

## Fluxo

1. Procura `node.exe` instalado no PATH e nos caminhos comuns do Windows.
2. Valida que o Node e 20+. O launcher **nao baixa outro Node** e nao altera a instalacao do usuario.
3. Executa `npm install` em segundo plano, sem abrir console.
4. Executa o seed do SQLite.
5. Inicia `backend/src/server.js` em segundo plano, com modo `fixture` por padrao.
6. Procura uma porta livre entre 3000 e 3010 e aguarda `/api/health`.
7. Abre o dashboard no navegador padrao.

## Diagnostico

Se alguma etapa falhar, o launcher mostra uma mensagem do Windows. Detalhes tecnicos ficam em `volix-launcher.log` e, quando o servidor chega a iniciar, em `volix-server.log`, na mesma pasta do `Volix.exe`.

## Compatibilidade

O backend foi ajustado para Node 20.0+ e usa `better-sqlite3` 11.10.0, uma versao com binarios precompilados para Node LTS e compatibilidade adequada com a faixa usada pelo projeto.
