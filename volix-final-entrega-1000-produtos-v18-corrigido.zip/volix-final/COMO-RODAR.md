# Como rodar o Volix

## 🪟 Windows

1. Extraia o ZIP completo.
2. Entre na pasta `volix-final`.
3. Dê **dois cliques em `Volix.exe`**.
4. Aguarde a preparação automática e o navegador abrir.

Não é necessário abrir CMD ou PowerShell.

## 🐧 Linux

1. Extraia o ZIP completo.
2. Entre na pasta `volix-final`.
3. Dê **dois cliques em `Volix`**.
4. Se o sistema perguntar, escolha **Executar**.
5. Aguarde o navegador abrir.

O arquivo `Volix` é o executável Linux. Não use `Volix.exe` no Linux.

Se a extração remover a permissão de execução, torne `Volix` executável uma única vez pelas propriedades do arquivo ou com `chmod +x Volix`.

## 🍎 macOS

Escolha o aplicativo conforme o Mac:

- Apple Silicon (M1/M2/M3/M4...): **`Volix-macOS-arm64.app`**
- Intel: **`Volix-macOS-x64.app`**

Depois, dê **dois cliques no `.app`**.

Na primeira abertura, se o Gatekeeper bloquear, use **Botão direito → Abrir → Abrir**. Isso acontece porque a entrega local não possui assinatura/notarização Apple.

Depois da primeira autorização, o `.app` pode ser aberto normalmente com dois cliques.

## Requisitos

- Node.js 20 ou superior
- npm
- conexão com a internet na primeira execução para instalar as dependências
- navegador padrão

## O que acontece ao abrir

O launcher encontra Node/npm, instala as dependências, prepara o SQLite, inicia o backend, testa `/api/health` e abre o dashboard automaticamente.

O modo padrão é `fixture`, usado para a demonstração local e sem tentativa de contornar mecanismos anti-bot da Shopee.

## Logs

- `volix-launcher.log` — launcher, Node/npm, instalação, seed, porta e healthcheck.
- `volix-server.log` — servidor Node e eventuais erros.
