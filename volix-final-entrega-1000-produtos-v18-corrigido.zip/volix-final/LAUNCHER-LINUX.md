# Launcher Linux — Volix

O arquivo **`Volix`** e um executavel nativo **ELF x86_64** para Linux. Ele e independente do `Volix.exe` do Windows.

## Requisitos

- Linux x86_64 com glibc
- Node.js 20 ou superior no `PATH`
- npm no `PATH`
- Internet na primeira execucao para instalar as dependencias
- Navegador padrao para abrir o dashboard

## Como usar

1. Extraia o ZIP completo.
2. Se o gerenciador de arquivos nao marcar o arquivo como executavel, rode uma vez:
   `chmod +x Volix`
3. Abra **`Volix`**.
4. O launcher instala as dependencias, prepara o SQLite, inicia o backend, verifica `/api/health` e abre o navegador.

Nao e necessario abrir terminal para o uso normal.

## O que o executavel faz

- Descobre `node` e `npm` diretamente pelo `PATH`.
- Valida Node.js 20+ antes de iniciar.
- Executa `npm install --no-audit --no-fund --engine-strict=false` no `backend`.
- Executa o seed do SQLite.
- Escolhe uma porta livre entre 3000 e 3010.
- Inicia o backend em modo `fixture`, como definido pela entrega local.
- Faz healthcheck HTTP real em `/api/health` antes de abrir o navegador.
- Abre `http://localhost:<porta>` com `xdg-open`.
- Mantem o processo launcher vivo enquanto o backend estiver rodando.
- Ao encerrar o launcher, envia SIGTERM ao backend.

## Diagnostico

- `volix-launcher.log`: descoberta de Node/npm, instalacao, seed, porta e healthcheck.
- `volix-server.log`: saida do backend e erros do Node.

Se `zenity` estiver instalado, erros sao exibidos em uma janela. Caso contrario, o launcher tenta `notify-send` e sempre registra os detalhes nos logs.

## Observacao sobre a Shopee

O modo local padrao continua sendo `fixture`; o launcher nao tenta burlar Akamai, CAPTCHA ou outros mecanismos anti-bot. A coleta publica permanece documentada no projeto e depende de acesso autorizado quando aplicavel.
