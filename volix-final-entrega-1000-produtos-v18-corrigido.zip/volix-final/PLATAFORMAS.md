# Volix — execução por sistema

O pacote foi preparado para o usuário final iniciar o Volix com **dois cliques**, sem precisar abrir terminal no uso normal.

## Windows 64-bit

- Abra **`Volix.exe`** com dois cliques.
- É um executável GUI nativo do Windows.
- Requer Node.js 20+ instalado.

## Linux 64-bit (x86_64)

- Abra **`Volix`** com dois cliques.
- É um executável ELF nativo Linux.
- O ZIP preserva a permissão de execução.
- Se o gerenciador de arquivos pedir confirmação, escolha **Executar**.
- Se a distribuição não preservar a permissão ao extrair, marque o arquivo como executável nas propriedades ou use `chmod +x Volix` uma única vez.
- Requer Node.js 20+ e npm.

## macOS

Escolha o aplicativo correspondente ao processador e abra com dois cliques:

- **`Volix-macOS-arm64.app`** → Apple Silicon (M1/M2/M3/M4 e posteriores)
- **`Volix-macOS-x64.app`** → Mac Intel

Os `.app` são bundles reais de aplicativo e já contêm o launcher e os arquivos necessários do projeto.

Na primeira abertura, o macOS pode exibir o bloqueio do Gatekeeper porque o aplicativo não é assinado/notarizado por um certificado Apple Developer. Nesse caso, use **Botão direito → Abrir → Abrir** uma vez. Depois disso, a abertura normal por dois cliques funciona.

## Fluxo automático

Ao abrir o launcher, ele:

1. encontra Node.js 20+ e npm;
2. instala as dependências do backend;
3. prepara o SQLite;
4. escolhe uma porta livre entre 3000 e 3010;
5. inicia o servidor;
6. aguarda o `/api/health` responder;
7. abre o navegador automaticamente.

Os logs ficam em `volix-launcher.log` e `volix-server.log` na pasta do projeto (ou dentro do `.app` no macOS).
