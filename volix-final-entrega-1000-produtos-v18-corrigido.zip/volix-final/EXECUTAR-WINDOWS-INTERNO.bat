@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

title VOLIX - Monitor de Precos Shopee

set "SHOPEE_PROVIDER_MODE=fixture"
set "FIXTURE_FALLBACK=true"
set "PORT=3000"
set "BACKEND_DIR=%~dp0backend"

cls
echo ========================================
echo   VOLIX - Monitor de Precos Shopee
echo   Windows - inicializacao
echo ========================================
echo.
echo Pasta: %~dp0
echo.

echo [1/6] Verificando Node.js...
where.exe node >nul 2>&1
if errorlevel 1 goto :node_error
node --version
if errorlevel 1 goto :node_error
echo.

echo [2/6] Verificando npm...
where.exe npm >nul 2>&1
if errorlevel 1 goto :npm_error
npm --version
if errorlevel 1 goto :npm_error
echo.

echo [3/6] Verificando versao do Node.js...
node -e "const [major,minor]=process.versions.node.split('.').map(Number); if(major<20 || (major===20 && minor<5)){console.error('Node.js 20.5 ou superior e necessario.'); process.exit(1)} console.log('Node.js compativel: '+process.versions.node)"
if errorlevel 1 goto :version_error
echo.

if not exist "%BACKEND_DIR%\package.json" goto :backend_error
if not exist "%BACKEND_DIR%\src\server.js" goto :backend_error

pushd "%BACKEND_DIR%"
if errorlevel 1 goto :backend_error

echo [4/6] Instalando dependencias do backend...
echo.
call npm.cmd install --no-audit --no-fund --engine-strict=false
if errorlevel 1 goto :install_error

echo.
echo Dependencias instaladas.
echo.

echo [5/6] Preparando banco SQLite...
echo.
call npm.cmd run seed
if errorlevel 1 goto :seed_error

echo.
echo Banco preparado.
echo.

echo [6/6] Iniciando aplicacao...
echo.
echo Modo: fixture local
echo Dashboard: http://localhost:3000
echo Health:    http://localhost:3000/api/health
echo.
echo Os dados de demonstracao sao locais; nenhuma requisicao publica
echo automatica a Shopee e feita neste modo.
echo.
echo Pressione Ctrl+C para encerrar o servidor.
echo.

call npm.cmd start
set "APP_EXIT=%errorlevel%"
popd

echo.
echo ========================================
echo   VOLIX ENCERRADO
echo   Codigo: %APP_EXIT%
echo ========================================
echo.
pause
exit /b %APP_EXIT%

:node_error
echo.
echo ========================================
echo ERRO: Node.js nao encontrado ou nao pode ser executado.
echo Instale Node.js 20.5 ou superior.
echo ========================================
echo.
pause
exit /b 1

:npm_error
echo.
echo ========================================
echo ERRO: npm nao encontrado ou nao pode ser executado.
echo Reinstale o Node.js 20.5 ou superior.
echo ========================================
echo.
pause
exit /b 1

:version_error
echo.
echo ========================================
echo ERRO: Node.js 20.5 ou superior e necessario.
echo ========================================
echo.
node --version
pause
exit /b 1

:backend_error
echo.
echo ========================================
echo ERRO: backend incompleto.
echo ========================================
echo Esperado:
echo %BACKEND_DIR%\package.json
echo %BACKEND_DIR%\src\server.js
echo.
pause
exit /b 1

:install_error
echo.
echo ========================================
echo ERRO AO INSTALAR DEPENDENCIAS.
echo ========================================
echo.
popd
pause
exit /b 1

:seed_error
echo.
echo ========================================
echo ERRO AO PREPARAR O BANCO SQLITE.
echo ========================================
echo.
popd
pause
exit /b 1
