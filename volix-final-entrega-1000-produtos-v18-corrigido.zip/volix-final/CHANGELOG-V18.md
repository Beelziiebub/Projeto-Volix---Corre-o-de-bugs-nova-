# Volix V18

## Correções

- Corrigida a expressão regular de `backend/src/scraper.js` que causava `Invalid regular expression: Unterminated character class` ao carregar o parser.
- Mantida a extração de strings JSON escapadas, IDs canônicos e preços da Shopee.
- Adicionado teste de regressão para payload JSON com aspas escapadas.

## Dependências

- Express atualizado para `4.22.3`.
- node-cron atualizado para `4.6.0`.
- Overrides de `body-parser`, `qs` e `path-to-regexp` para versões corrigidas.

## Validação

- `node --check backend/src/scraper.js` validado.
- Os testes completos precisam ser executados em uma máquina com as dependências instaladas; o ambiente de empacotamento não conseguiu concluir o download do npm.
