//go:build !windows
package main

import "os/exec"

func command(name string, args ...string) *exec.Cmd { return exec.Command(name, args...) }

func showError(title, text string) {
    if p, err := exec.LookPath("zenity"); err == nil {
        _ = exec.Command(p, "--error", "--title", title, "--text", text).Run()
        return
    }
    if p, err := exec.LookPath("osascript"); err == nil {
        _ = exec.Command(p, "-e", `display dialog "`+escapeAppleScript(text)+`" with title "`+escapeAppleScript(title)+`" buttons {"OK"} default button "OK" with icon stop`).Run()
        return
    }
    if p, err := exec.LookPath("notify-send"); err == nil { _ = exec.Command(p, title, text).Run() }
}

func escapeAppleScript(s string) string {
    s = replace(s, `\`, `\\`)
    s = replace(s, `"`, `\"`)
    s = replace(s, "\n", "\\n")
    return s
}

func replace(s, old, new string) string {
    for {
        n := 0
        for i := 0; i+len(old) <= len(s); i++ { if s[i:i+len(old)] == old { n++ } }
        if n == 0 { return s }
        out := make([]byte, 0, len(s)+n*(len(new)-len(old)))
        for i := 0; i < len(s); {
            if i+len(old) <= len(s) && s[i:i+len(old)] == old { out = append(out, new...); i += len(old) } else { out = append(out, s[i]); i++ }
        }
        s = string(out)
    }
}

func openBrowser(url string) {
    if p, err := exec.LookPath("xdg-open"); err == nil { _ = exec.Command(p, url).Start(); return }
    if p, err := exec.LookPath("open"); err == nil { _ = exec.Command(p, url).Start(); return }
}
