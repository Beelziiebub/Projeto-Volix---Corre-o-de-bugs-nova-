# Build do launcher

O launcher e escrito em Go e compilado com `CGO_ENABLED=0`, permitindo builds nativos para Windows, Linux e macOS sem DLL/biblioteca Go externa em runtime.

Alvos desta entrega:
- windows/amd64 -> Volix.exe (GUI)
- linux/amd64 -> Volix
- darwin/amd64 -> Volix-macOS-x64
- darwin/arm64 -> Volix-macOS-arm64

O aplicativo macOS tambem e empacotado em `.app` para cada arquitetura.
