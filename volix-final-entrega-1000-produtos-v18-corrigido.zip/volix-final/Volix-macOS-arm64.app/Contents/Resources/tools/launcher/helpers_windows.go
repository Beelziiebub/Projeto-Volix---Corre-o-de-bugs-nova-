//go:build windows
package main

import (
    "os/exec"
    "syscall"
    "unsafe"
)

func command(name string, args ...string) *exec.Cmd {
    c := exec.Command(name, args...)
    c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
    return c
}

func showError(title, text string) {
    u := syscall.NewLazyDLL("user32.dll")
    p := u.NewProc("MessageBoxW")
    t, _ := syscall.UTF16PtrFromString(title)
    m, _ := syscall.UTF16PtrFromString(text)
    p.Call(0, uintptr(unsafe.Pointer(m)), uintptr(unsafe.Pointer(t)), 0x10)
}

func openBrowser(url string) {
    _ = exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", url).Start()
}
