package main

import (
    "fmt"
    "io"
    "net"
    "net/http"
    "os"
    "os/exec"
    "path/filepath"
    "runtime"
    "strconv"
    "strings"
    "time"
)

const minNodeMajor = 20
const firstPort = 3000
const lastPort = 3010

func rootDir() string {
    exe, err := os.Executable()
    if err != nil { return "." }
    if real, err := filepath.EvalSymlinks(exe); err == nil { exe = real }
    dir := filepath.Dir(exe)
    // Inside a macOS .app, the executable lives at Contents/MacOS.
    // Project files are bundled in Contents/Resources, so use that as root.
    if runtime.GOOS == "darwin" {
        if filepath.Base(dir) == "MacOS" && filepath.Base(filepath.Dir(dir)) == "Contents" {
            resources := filepath.Join(filepath.Dir(dir), "Resources")
            if _, err := os.Stat(filepath.Join(resources, "backend", "package.json")); err == nil {
                return resources
            }
        }
    }
    return dir
}

func logLine(root, format string, args ...any) {
    f, err := os.OpenFile(filepath.Join(root, "volix-launcher.log"), os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
    if err != nil { return }
    defer f.Close()
    fmt.Fprintf(f, "%s "+format+"\n", append([]any{time.Now().Format(time.RFC3339)}, args...)...)
}

func runCapture(dir, program string, args ...string) (string, int, error) {
    cmd := command(program, args...)
    cmd.Dir = dir
    var b strings.Builder
    cmd.Stdout = &b
    cmd.Stderr = &b
    err := cmd.Run()
    code := 0
    if err != nil {
        if ee, ok := err.(*exec.ExitError); ok { code = ee.ExitCode() } else { code = -1 }
    }
    return b.String(), code, err
}

func findNode(root string) (string, string, error) {
    candidates := []string{}
    if p, err := exec.LookPath("node"); err == nil { candidates = append(candidates, p) }
    if runtime.GOOS == "windows" {
        if p, err := exec.LookPath("node.exe"); err == nil { candidates = append(candidates, p) }
        candidates = append(candidates,
            filepath.Join(os.Getenv("ProgramFiles"), "nodejs", "node.exe"),
            filepath.Join(os.Getenv("ProgramFiles(x86)"), "nodejs", "node.exe"),
            filepath.Join(os.Getenv("LOCALAPPDATA"), "Programs", "nodejs", "node.exe"),
        )
    } else {
        candidates = append(candidates, "/usr/local/bin/node", "/opt/homebrew/bin/node", "/usr/bin/node")
    }
    seen := map[string]bool{}
    for _, p := range candidates {
        if p == "" || seen[p] { continue }
        seen[p] = true
        if _, err := os.Stat(p); err != nil { continue }
        out, code, err := runCapture(filepath.Dir(p), p, "-p", "process.versions.node")
        if err != nil || code != 0 { continue }
        v := strings.TrimSpace(out)
        parts := strings.Split(v, ".")
        if len(parts) == 0 { continue }
        major, err := strconv.Atoi(parts[0])
        if err == nil && major >= minNodeMajor { return p, v, nil }
    }
    return "", "", fmt.Errorf("Node.js %d+ nao encontrado", minNodeMajor)
}

func findNpm(node string) string {
    dir := filepath.Dir(node)
    if runtime.GOOS == "windows" {
        for _, p := range []string{filepath.Join(dir, "npm.cmd"), filepath.Join(dir, "npm.exe")} {
            if _, err := os.Stat(p); err == nil { return p }
        }
        if p, err := exec.LookPath("npm.cmd"); err == nil { return p }
    }
    if p, err := exec.LookPath("npm"); err == nil { return p }
    return ""
}

func runNpm(root, npm string, args ...string) (string, int, error) {
    if runtime.GOOS != "windows" { return runCapture(root, npm, args...) }
    // npm.cmd is a Windows batch file. A temporary .bat avoids cmd.exe quoting edge cases.
    bat := filepath.Join(root, ".volix-npm-run.bat")
    var b strings.Builder
    b.WriteString("@echo off\r\ncall \"")
    b.WriteString(strings.ReplaceAll(npm, "\"", "\"\""))
    b.WriteString("\"")
    for _, a := range args {
        b.WriteByte(' ')
        b.WriteString("\"")
        b.WriteString(strings.ReplaceAll(a, "\"", "\"\""))
        b.WriteString("\"")
    }
    b.WriteString("\r\nexit /b %errorlevel%\r\n")
    if err := os.WriteFile(bat, []byte(b.String()), 0600); err != nil { return "", -1, err }
    defer os.Remove(bat)
    return runCapture(root, "cmd.exe", "/d", "/c", bat)
}

func startServer(root, node, backend string, port int) (*exec.Cmd, *os.File, error) {
    cmd := command(node, filepath.Join("src", "server.js"))
    cmd.Dir = backend
    cmd.Env = append(os.Environ(),
        "SHOPEE_PROVIDER_MODE=fixture",
        "FIXTURE_FALLBACK=true",
        fmt.Sprintf("PORT=%d", port),
    )
    logFile, err := os.OpenFile(filepath.Join(root, "volix-server.log"), os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
    if err != nil { return nil, nil, err }
    cmd.Stdout = logFile
    cmd.Stderr = logFile
    if err := cmd.Start(); err != nil { logFile.Close(); return nil, nil, err }
    return cmd, logFile, nil
}

func portFree(port int) bool {
    ln, err := net.Listen("tcp", fmt.Sprintf("127.0.0.1:%d", port))
    if err != nil { return false }
    ln.Close()
    return true
}

func waitHealth(port int) bool {
    client := &http.Client{Timeout: 1 * time.Second}
    url := fmt.Sprintf("http://127.0.0.1:%d/api/health", port)
    for i := 0; i < 90; i++ {
        resp, err := client.Get(url)
        if err == nil {
            body, _ := io.ReadAll(resp.Body)
            resp.Body.Close()
            if resp.StatusCode >= 200 && resp.StatusCode < 300 && strings.Contains(string(body), `"ok":true`) { return true }
        }
        time.Sleep(500 * time.Millisecond)
    }
    return false
}

func main() {
    root := rootDir()
    _ = os.Remove(filepath.Join(root, "volix-launcher.log"))
    logLine(root, "inicio do launcher nativo (%s/%s)", runtime.GOOS, runtime.GOARCH)

    node, nodeVersion, err := findNode(root)
    if err != nil {
        logLine(root, "Node: %v", err)
        showError("Volix", "Node.js 20 ou superior nao foi encontrado.\n\nInstale Node.js 20+ e tente novamente.")
        return
    }
    logLine(root, "Node encontrado: %s (%s)", node, nodeVersion)
    os.Setenv("PATH", filepath.Dir(node)+string(os.PathListSeparator)+os.Getenv("PATH"))

    npm := findNpm(node)
    if npm == "" {
        logLine(root, "npm nao encontrado")
        showError("Volix", "npm nao foi encontrado na instalacao do Node.js.\n\nReinstale o Node.js 20+ e tente novamente.")
        return
    }
    logLine(root, "npm encontrado: %s", npm)

    backend := filepath.Join(root, "backend")
    if _, err := os.Stat(filepath.Join(backend, "package.json")); err != nil {
        logLine(root, "backend/package.json ausente: %v", err)
        showError("Volix", "A pasta backend nao foi encontrada.\n\nExtraia o pacote completo e execute o Volix dentro da pasta do projeto.")
        return
    }

    os.Setenv("SHOPEE_PROVIDER_MODE", "fixture")
    os.Setenv("FIXTURE_FALLBACK", "true")

    logLine(root, "npm install iniciado")
    out, code, err := runNpm(root, npm, "--prefix", backend, "install", "--no-audit", "--no-fund", "--engine-strict=false")
    logLine(root, "npm install exit=%d err=%v\n%s", code, err, out)
    if err != nil || code != 0 {
        showError("Volix", "Falha ao instalar as dependencias.\n\nVeja volix-launcher.log para detalhes.")
        return
    }

    logLine(root, "seed SQLite iniciado")
    out, code, err = runNpm(root, npm, "--prefix", backend, "run", "seed")
    logLine(root, "seed exit=%d err=%v\n%s", code, err, out)
    if err != nil || code != 0 {
        showError("Volix", "Falha ao preparar o banco SQLite.\n\nVeja volix-launcher.log para detalhes.")
        return
    }

    port := 0
    for p := firstPort; p <= lastPort; p++ { if portFree(p) { port = p; break } }
    if port == 0 {
        showError("Volix", "Nenhuma porta livre entre 3000 e 3010.")
        return
    }
    logLine(root, "porta escolhida: %d", port)

    cmd, logFile, err := startServer(root, node, backend, port)
    if err != nil {
        logLine(root, "falha ao iniciar servidor: %v", err)
        showError("Volix", "Nao foi possivel iniciar o servidor.\n\nVeja volix-server.log.")
        return
    }
    logLine(root, "servidor iniciado pid=%d", cmd.Process.Pid)

    ready := waitHealth(port)
    if !ready {
        logLine(root, "healthcheck expirou na porta %d", port)
        _ = cmd.Process.Kill()
        _ = logFile.Close()
        showError("Volix", "O servidor nao respondeu ao healthcheck.\n\nVeja volix-server.log.")
        return
    }

    url := fmt.Sprintf("http://localhost:%d", port)
    logLine(root, "Volix pronto: %s", url)
    openBrowser(url)

    err = cmd.Wait()
    _ = logFile.Close()
    logLine(root, "servidor finalizado: %v", err)
}
