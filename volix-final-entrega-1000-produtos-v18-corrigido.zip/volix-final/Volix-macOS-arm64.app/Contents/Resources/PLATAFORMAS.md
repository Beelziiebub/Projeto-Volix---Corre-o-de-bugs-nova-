# Volix — executáveis por sistema

## Windows 64-bit
- `Volix.exe`
- Executável GUI nativo, sem janela de terminal.
- Requer Node.js 20+ instalado.

## Linux 64-bit (x86_64)
- `Volix`
- ELF x86_64 nativo.
- Torne-o executável se o ZIP perder a permissão: `chmod +x Volix`.
- Requer Node.js 20+ e npm.
- Abre o navegador com `xdg-open`.

## macOS
Há dois executáveis nativos e dois aplicativos:
- Apple Silicon (M1/M2/M3/M4...): `Volix-macOS-arm64` ou `Volix-macOS-arm64.app`
- Intel: `Volix-macOS-x64` ou `Volix-macOS-x64.app`
- Requer Node.js 20+ e npm.
- O launcher abre o navegador com `open`.

### Primeira abertura no macOS
Os binários deste pacote não são assinados/notarizados com um certificado Apple Developer. Se o Gatekeeper bloquear a primeira abertura, use **Botão direito > Abrir** e confirme. Isso é uma limitação de distribuição local, não do launcher.

## Fluxo comum
1. O launcher encontra Node.js 20+ e npm.
2. Instala as dependências do backend.
3. Executa o seed do SQLite.
4. Escolhe uma porta livre entre 3000 e 3010.
5. Inicia o servidor e aguarda `/api/health`.
6. Só então abre `http://localhost:<porta>` no navegador.
7. Os logs ficam em `volix-launcher.log` e `volix-server.log`.

O modo padrão é `fixture`, portanto a demonstração local não depende de uma coleta pública da Shopee nem tenta contornar mecanismos anti-bot.
