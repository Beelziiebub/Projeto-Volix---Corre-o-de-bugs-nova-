#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND_DIR="$ROOT_DIR/backend"

fail() { echo; echo "[ERRO] $1" >&2; exit 1; }

command -v node >/dev/null 2>&1 || fail "Node.js não encontrado. Instale Node.js 20.5 ou superior."
command -v npm >/dev/null 2>&1 || fail "npm não encontrado. Instale Node.js 20.5 ou superior."
NODE_MAJOR="$(node -p "process.versions.node.split('.')[0]")"
[[ "$NODE_MAJOR" =~ ^[0-9]+$ ]] && (( NODE_MAJOR >= 20 )) || fail "Node.js 20.5+ é obrigatório. Encontrado: $(node --version)"

cd "$ROOT_DIR"
echo "========================================"
echo "  VOLIX — Monitor de preços"
echo "========================================"
printf 'Node: %s\nnpm:  %s\n\n' "$(node --version)" "$(npm --version)"

echo "[1/5] Instalando dependências..."
npm --prefix "$BACKEND_DIR" install

echo
echo "[2/5] Preparando SQLite..."
npm --prefix "$BACKEND_DIR" run seed

echo
echo "[3/5] Executando testes..."
npm --prefix "$BACKEND_DIR" test

echo
echo "[4/5] Verificando JavaScript..."
while IFS= read -r -d '' file; do node --check "$file"; done < <(find "$BACKEND_DIR/src" "$BACKEND_DIR/tests" -type f -name '*.js' -print0)

echo
echo "[5/5] Iniciando aplicação em modo demonstração..."
echo "Dashboard: http://localhost:3000"
echo "Health:    http://localhost:3000/api/health"
echo "Provider:  fixture (sem coleta pública automática)"
echo "Pressione Ctrl+C para encerrar."
echo
export SHOPEE_PROVIDER_MODE="${SHOPEE_PROVIDER_MODE:-fixture}"
export FIXTURE_FALLBACK="${FIXTURE_FALLBACK:-true}"
npm --prefix "$BACKEND_DIR" start
