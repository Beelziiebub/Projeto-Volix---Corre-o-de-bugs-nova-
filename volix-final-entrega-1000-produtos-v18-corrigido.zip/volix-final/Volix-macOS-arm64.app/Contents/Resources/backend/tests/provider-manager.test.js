import test from 'node:test';
import assert from 'node:assert/strict';
import { markPublicBlocked, publicCollectionAvailable, clearPublicBlock, providerStatus } from '../src/provider-manager.js';

test('circuit breaker blocks repeated public attempts and can reset', () => {
  clearPublicBlock();
  assert.equal(publicCollectionAvailable(), true);
  markPublicBlocked('shopee.com.br', 'ANTI_BOT_CHALLENGE', 1000);
  assert.equal(publicCollectionAvailable(), false);
  assert.equal(providerStatus().public_http.reason, 'ANTI_BOT_CHALLENGE');
  clearPublicBlock();
  assert.equal(publicCollectionAvailable(), true);
});
