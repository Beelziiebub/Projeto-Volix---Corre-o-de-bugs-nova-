import test from 'node:test';
import assert from 'node:assert/strict';
import { fixtureForUrl, listFixtures, fixtureToProduct } from '../src/fixtures.js';

test('fixtures contêm os 5 produtos de referência', () => {
  const fixtures=listFixtures();
  assert.equal(fixtures.length,5);
  for(const f of fixtures) assert.match(f.url,/-i\.\d+\.\d+/i);
});

test('fixture é transformada em produto sem fingir coleta live', () => {
  const f=listFixtures()[0];
  const p=fixtureToProduct(f);
  assert.equal(p.data_source, undefined);
  assert.equal(p.price_pix,f.price_pix);
  assert.ok(p.shopee_shop_id);
  assert.ok(p.shopee_item_id);
  assert.equal(fixtureForUrl(f.url).url,f.url);
});
