const fixtures = [
  { name:'Smartwatch Relógio Inteligente Haiz My Watch I Fit', url:'https://shopee.com.br/Smartwatch-Rel%C3%B3gio-Inteligente-Haiz-My-Watch-I-Fit-i.1612621589.58206596137', price_pix:133.00, price_card:139.99, attributes:{Categoria:'Eletrônicos / vestível',Variacoes:'3'}, variants:[{name:'3 variações disponíveis'}], description:'Snapshot demonstrativo para execução local quando a coleta pública da Shopee estiver bloqueada.' },
  { name:'Fritadeira Sem Óleo Air Fryer 3,5L Mondial AF-30-I 220V', url:'https://shopee.com.br/Fritadeira-Sem-%C3%93leo-Air-Fryer-3-5L-Mondial-AF-30-I-220V-i.707764315.23098739486', price_pix:323.91, price_card:359.90, attributes:{Categoria:'Casa / eletroportáteis',Marca:'Mondial'}, variants:[], description:'Snapshot demonstrativo para execução local quando a coleta pública da Shopee estiver bloqueada.' },
  { name:'fone de ouvido bluetooth Y30 Tws resistente a água com microfone original', url:'https://shopee.com.br/fone-de-ouvido-bluetooth-Y30-Tws-resistente-a-%C3%A1gua-com-microfone-original-i.297251051.19725181060', price_pix:34.90, price_card:39.90, attributes:{Categoria:'Áudio',Modelo:'Y30 TWS'}, variants:[{name:'Fone na caixa'},{name:'Fone na embalagem plástica'}], description:'Snapshot demonstrativo para execução local quando a coleta pública da Shopee estiver bloqueada.' },
  { name:'Caixa De Som Bluetooth Imenso I X51 120w Ipx4 Rgb C/ 2 Mic', url:'https://shopee.com.br/Caixa-De-Som-Bluetooth-Imenso-I-X51-120w-Ipx4-Rgb-C-2-Mic-i.551459340.22598400913', price_pix:432.00, price_card:480.00, attributes:{Categoria:'Áudio',Potencia:'120W',Protecao:'IPX4'}, variants:[], description:'Snapshot demonstrativo para execução local quando a coleta pública da Shopee estiver bloqueada.' },
  { name:'Suporte De Parede Para Controle Remoto I Organizador De Controles Remoto', url:'https://shopee.com.br/Suporte-De-Parede-Para-Controle-Remoto-I-Organizador-De-Controles-Remoto-i.330461348.22694882636', price_pix:23.74, price_card:24.99, attributes:{Categoria:'Casa',Variacoes:'2'}, variants:[], description:'Snapshot demonstrativo para execução local quando a coleta pública da Shopee estiver bloqueada.' }
];

function clone(x){return JSON.parse(JSON.stringify(x));}
export function fixtureForUrl(url){
  const raw=String(url||'').trim();
  const normalize=u=>String(u||'').trim().replace(/\/+$/,'').split(/[?#]/,1)[0];
  const exact=normalize(raw);
  let f=fixtures.find(x=>normalize(x.url)===exact);
  if(f) return clone(f);
  const m=raw.match(/-i\.(\d+)\.(\d+)/i);
  if(!m) return null;
  f=fixtures.find(x=>{ const mm=x.url.match(/-i\.(\d+)\.(\d+)/i); return mm && mm[1]===m[1] && mm[2]===m[2]; });
  if(f) return clone(f);
  const rawName=decodeURIComponent(raw.split('/').pop()?.split('-i.')[0] || 'Produto Shopee');
  const name=rawName.replace(/[-_]+/g,' ').replace(/\s+/g,' ').trim().replace(/\b\w/g,c=>c.toUpperCase()).slice(0,140) || 'Produto Shopee';
  const n=Number(m[2]);
  const pricePix=Number((49.90 + (n % 3500) / 10).toFixed(2));
  return {
    name, url:raw, price_pix:pricePix, price_card:Number((pricePix*1.08).toFixed(2)),
    attributes:{Categoria:'Catálogo Shopee · snapshot local',Fonte:'Demonstração local',ItemID:m[2],LojaID:m[1]},
    variants:[], seller:'Snapshot local', rating:4.8, rating_count:1200, sold_count:350,
    description:'Snapshot local de demonstração associado à URL informada. Nenhum dado live é afirmado como coletado.', images:[]
  };
}
export function listFixtures(){return fixtures.map(clone);}
export function fixtureToProduct(f,url=f.url){
  return {...clone(f),url,shopee_shop_id:url.match(/i\.(\d+)\./i)?.[1]??null,shopee_item_id:url.match(/-i\.\d+\.(\d+)/i)?.[1]??null,brand:f.attributes?.Marca??null,seller:'Snapshot demonstrativo',rating:null,rating_count:null,sold_count:null,images:[],attributes:f.attributes||{},variants:f.variants||[]};
}
