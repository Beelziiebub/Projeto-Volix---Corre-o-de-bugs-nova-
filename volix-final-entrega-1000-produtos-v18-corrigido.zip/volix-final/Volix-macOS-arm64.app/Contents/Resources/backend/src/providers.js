/**
 * Providers de dados da Shopee.
 *
 * A integração autorizada é deliberadamente configurável: o projeto não
 * inventa endpoint, assinatura ou contrato da Shopee. Quando SHOPEE_AUTHORIZED_PROVIDER_URL
 * estiver configurado, esse endpoint deve pertencer a uma integração autorizada
 * e devolver um produto já normalizado no contrato abaixo.
 */

export const authorizedProviderConfigured = () => Boolean(String(process.env.SHOPEE_AUTHORIZED_PROVIDER_URL || '').trim());

function normalizeProduct(raw, sourceUrl) {
  const p = raw?.product ?? raw;
  if (!p || typeof p !== 'object' || !p.name) {
    throw new Error('AUTHORIZED_PROVIDER_INVALID_RESPONSE');
  }
  return {
    ...p,
    url: p.url || sourceUrl,
    attributes: Array.isArray(p.attributes) ? p.attributes : [],
    images: Array.isArray(p.images) ? p.images : [],
    variants: Array.isArray(p.variants) ? p.variants : []
  };
}

export async function collectFromAuthorizedProvider(sourceUrl, { timeout = 15000 } = {}) {
  const endpoint = String(process.env.SHOPEE_AUTHORIZED_PROVIDER_URL || '').trim();
  if (!endpoint) throw new Error('AUTHORIZED_PROVIDER_NOT_CONFIGURED');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
    const token = String(process.env.SHOPEE_AUTHORIZED_PROVIDER_TOKEN || '').trim();
    if (token) headers.Authorization = `Bearer ${token}`;

    const response = await fetch(endpoint, {
      method: 'POST',
      headers,
      body: JSON.stringify({ url: sourceUrl }),
      signal: controller.signal
    });
    const text = await response.text();
    let payload;
    try { payload = JSON.parse(text); } catch { throw new Error('AUTHORIZED_PROVIDER_INVALID_JSON'); }
    if (!response.ok) {
      const error = new Error(`AUTHORIZED_PROVIDER_HTTP_${response.status}`);
      error.status = response.status;
      throw error;
    }
    return normalizeProduct(payload, sourceUrl);
  } finally {
    clearTimeout(timer);
  }
}
