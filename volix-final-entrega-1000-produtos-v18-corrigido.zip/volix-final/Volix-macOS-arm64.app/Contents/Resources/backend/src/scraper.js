import * as cheerio from 'cheerio';

const BLOCK_PATTERNS = [
  /access denied/i, /verify you are human/i, /captcha/i, /akamai/i,
  /bot manager/i, /too many requests/i, /security verification/i,
  /are you a robot/i, /unusual traffic/i
];
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

function clean(value) { return String(value ?? '').replace(/\s+/g,' ').trim(); }
function firstText($, selectors) { for (const selector of selectors) { const value=clean($(selector).first().text()); if(value)return value; } return null; }
function meta($, name) { return clean($(`meta[property="${name}"],meta[name="${name}"]`).attr('content')) || null; }
function money(value) {
  if(value==null)return null;
  const raw=clean(value).replace(/R\$/gi,'');
  const match=raw.match(/\d[\d.]*,\d{2}|\d+(?:\.\d+)?/);
  if(!match)return null;
  const token=match[0];
  return token.includes(',') ? Number(token.replace(/\./g,'').replace(',','.')) : Number(token);
}
function scriptTexts($) { const out=[]; $('script').each((_,el)=>{const text=$(el).html()||'';if(/price|itemid|shopid|description|rating|variation|model/i.test(text))out.push(text);});return out; }
function jsonValue(text, keys) {
  for(const key of keys){
    const escaped=key.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    const re=new RegExp(`"${escaped}"\\s*:\\s*(?:"([^"\\]*(?:\\.[^"\\]*)*)"|(\\-?\\d+(?:\\.\\d+)?))`,'i');
    const m=text.match(re); if(m)return m[1] ?? m[2];
  }
  return null;
}
function normalizePrice(value){
  const n=Number(value);
  if(!Number.isFinite(n)||n<=0)return null;
  // Payloads da Shopee podem representar preço em unidades de 1/100000
  // ou em centavos. Mantemos valores decimais já normalizados.
  if(n >= 100000) return Number((n/100000).toFixed(2));
  if(Number.isInteger(n) && n >= 1000) return Number((n/100).toFixed(2));
  return Number(n.toFixed(2));
}
function extractAttributes($){
  const attributes={};
  $('table tr').each((_,row)=>{const cells=$(row).find('td,th').map((__,cell)=>clean($(cell).text())).get().filter(Boolean);if(cells.length>=2)attributes[cells[0]]=cells.slice(1).join(' ');});
  return attributes;
}
function extractImages($){
  const urls=new Set();
  for(const selector of ['meta[property="og:image"]','meta[name="twitter:image"]']) $(selector).each((_,el)=>{const u=$(el).attr('content');if(u&&/^https?:\/\//i.test(u))urls.add(u);});
  $('img').each((_,img)=>{for(const attr of ['src','data-src','data-lazy-src']){const u=$(img).attr(attr);if(u&&/^https?:\/\//i.test(u)){urls.add(u);break;}}});
  return [...urls].slice(0,20);
}
function extractVariants($, scripts){
  const variants=[]; const add=(v)=>{const name=clean(v.name);if(name&&!variants.some(x=>x.name===name&&x.sku===v.sku))variants.push({sku:v.sku??null,name,price_pix:v.price_pix??null,price_card:v.price_card??null});};
  $('[class*="variation"] button,[class*="variation"] [class*="name"],[data-testid*="variation"] button').each((_,el)=>add({name:$(el).text()}));
  const variationText=jsonValue(scripts,['model_name','variation_name']); if(variationText)add({name:variationText});
  return variants.slice(0,50);
}

export function parseShopeeHtml(html,url){
  const $=cheerio.load(html); const scripts=scriptTexts($).join('\n');
  const name=meta($,'og:title')||firstText($,['h1','[data-testid="pdp-product-title"]'])||jsonValue(scripts,['name','product_name'])||'Produto Shopee';
  const description=meta($,'og:description')||firstText($,['[data-testid="pdp-product-description"]','.product-detail'])||jsonValue(scripts,['description','product_description'])||'';
  const canonical=$('link[rel="canonical"]').attr('href')||url;
  const shop=jsonValue(scripts,['shopid','shop_id']); const item=jsonValue(scripts,['itemid','item_id']);
  const ratingRaw=jsonValue(scripts,['rating_star','rating']); const ratingCountRaw=jsonValue(scripts,['rating_count']); const soldRaw=jsonValue(scripts,['historical_sold','sold']);
  const rawPrice=jsonValue(scripts,['price']); const rawMinPrice=jsonValue(scripts,['min_price']); const rawOriginal=jsonValue(scripts,['price_before_discount','original_price']);
  const visiblePrice=money(firstText($,['[class*="price"]','.price']));
  const card=normalizePrice(rawPrice)??visiblePrice; const pix=normalizePrice(rawMinPrice)??visiblePrice;
  const attrs=extractAttributes($);
  return {name,description,url:canonical,shopee_shop_id:shop?String(shop):null,shopee_item_id:item?String(item):null,
    brand:attrs.Marca||attrs.Brand||null,seller:firstText($,['.shop-name','[class*="shop-name"]']),
    rating:ratingRaw?Number(ratingRaw):null,rating_count:ratingCountRaw?Number(ratingCountRaw):null,sold_count:soldRaw?Number(soldRaw):null,
    price_pix:pix,price_card:card??(rawOriginal?normalizePrice(rawOriginal):null),images:extractImages($),attributes:attrs,variants:extractVariants($,scripts)};
}

export function looksBlocked(html,status){return [401,403,429].includes(status)||BLOCK_PATTERNS.some(p=>p.test(html));}

function retryAfterMs(value){
  if(!value) return 0;
  const seconds=Number(value);
  if(Number.isFinite(seconds)) return Math.max(0, seconds*1000);
  const date=Date.parse(value);
  return Number.isFinite(date) ? Math.max(0, date-Date.now()) : 0;
}

export async function fetchHtml(url,{retries=4,timeout=15000}={}){
  let lastError;
  const diagnostics={url,attempts:0,last_status:null,final_url:null,content_type:null,reason:null,duration_ms:0};
  for(let attempt=1;attempt<=retries;attempt++){
    const started=Date.now(); let timer; diagnostics.attempts=attempt;
    try{
      const controller=new AbortController(); timer=setTimeout(()=>controller.abort(),timeout);
      const response=await fetch(url,{redirect:'follow',signal:controller.signal,headers:{'User-Agent':process.env.SCRAPER_USER_AGENT||'VolixCatalogMonitor/1.2 (public catalog collection)','Accept-Language':'pt-BR,pt;q=0.9,en;q=0.7','Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'}});
      const html=await response.text(); if(timer)clearTimeout(timer);
      diagnostics.last_status=response.status; diagnostics.final_url=response.url; diagnostics.content_type=response.headers.get('content-type'); diagnostics.duration_ms=Date.now()-started;
      if(!response.ok){const error=new Error(`HTTP_${response.status}`);error.code='HTTP_ERROR';error.status=response.status;error.diagnostics={...diagnostics};throw error;}
      if(looksBlocked(html,response.status)){const error=new Error('ANTI_BOT_CHALLENGE');error.code='ANTI_BOT_CHALLENGE';error.status=response.status;error.diagnostics={...diagnostics,reason:'challenge-marker'};throw error;}
      console.info(`[scraper] sucesso tentativa=${attempt} ms=${Date.now()-started}`); return html;
    }catch(error){lastError=error;
      error.diagnostics={attempts:attempt,last_status:error.status??null,retry_after_ms:error.retryAfterMs??0}; if(timer)clearTimeout(timer);console.warn(`[scraper] falha tentativa=${attempt}/${retries} erro=${error.message} status=${error.status??diagnostics.last_status??'—'}`);if(attempt<retries)await sleep(750*2**(attempt-1));}
  }
  if(lastError && !lastError.diagnostics) lastError.diagnostics={...diagnostics};
  throw lastError;
}
export async function scrapeShopee(url,options={}){const html=await fetchHtml(url,options);return parseShopeeHtml(html,url);}
export async function searchShopee(query,options={}){
  const html=await fetchHtml(`https://shopee.com.br/search?keyword=${encodeURIComponent(query)}`,options); const $=cheerio.load(html); const results=[]; const seen=new Set();
  $('a[href*="-i."]').each((_,el)=>{const href=$(el).attr('href');const title=clean($(el).text());if(!href)return;const absolute=new URL(href,'https://shopee.com.br').href;if(!seen.has(absolute)&&title){seen.add(absolute);results.push({title,url:absolute});}});
  return results.slice(0,20);
}
