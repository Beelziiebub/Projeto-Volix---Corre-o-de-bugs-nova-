# Como rodar o projeto Volix

Esta pasta já contém os executáveis nativos e os scripts de execução. **Não é necessário abrir o código-fonte para iniciar o sistema.**

## Requisito para todos os sistemas

- Node.js 20.5 ou superior
- npm (instalado junto com Node.js)
- Navegador moderno

O launcher usa o Node.js instalado no computador para executar o backend e instalar as dependências na primeira execução.

---

## Windows — mais fácil: duplo clique no executável

1. Extraia o ZIP completo.
2. Entre na pasta `volix-final`.
3. Dê **duplo clique em `Volix.exe`**.
4. Aguarde o launcher preparar as dependências, o banco e iniciar o servidor.
5. O navegador será aberto automaticamente quando o `/api/health` estiver respondendo.
6. Se o navegador não abrir sozinho, acesse:

```text
http://localhost:3000
```

### Importante no Windows

- **`Volix.exe` = Windows.**
- **`Volix` (sem `.exe`) = Linux.**
- O Windows pode esconder a extensão `.exe`, mas os arquivos são diferentes.
- Não é necessário abrir `EXECUTAR-WINDOWS.bat` quando estiver usando `Volix.exe`.

### Alternativa por script

Também é possível executar:

```text
EXECUTAR-WINDOWS.bat
```

Ou pelo PowerShell:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\EXECUTAR-WINDOWS.ps1
```

---

## Linux — executável nativo

Na pasta `volix-final`, abra um terminal e execute uma vez:

```bash
chmod +x Volix
```

Depois:

```bash
./Volix
```

O launcher irá:

1. localizar o Node.js e o npm;
2. instalar as dependências do backend;
3. preparar o banco SQLite;
4. executar o seed/testes necessários;
5. iniciar o servidor;
6. verificar o `/api/health`;
7. abrir o navegador.

Dashboard:

```text
http://localhost:3000
```

### Atalho Linux

Se o ambiente gráfico permitir executar arquivos diretamente, também existe:

```text
Volix.desktop
```

Caso o sistema não permita executar o `.desktop` com duplo clique, use `./Volix` pelo terminal.

### Importante no Linux

O arquivo **`Volix` é o executável Linux x86_64**. Ele não é o mesmo arquivo que `Volix.exe` do Windows.

---

## macOS — Apple Silicon (M1/M2/M3/M4...)

Use:

```text
Volix-macOS-arm64.app
```

Pode abrir pelo Finder com duplo clique. Se necessário, pelo Terminal na pasta do projeto:

```bash
open Volix-macOS-arm64.app
```

Também existe o executável:

```text
Volix-macOS-arm64
```

---

## macOS — Intel

Use:

```text
Volix-macOS-x64.app
```

Pode abrir pelo Finder com duplo clique. Pelo Terminal:

```bash
open Volix-macOS-x64.app
```

Também existe o executável:

```text
Volix-macOS-x64
```

### Se o macOS bloquear a primeira abertura

Como o aplicativo não é assinado/notarizado pela Apple, o Gatekeeper pode pedir autorização na primeira execução. Nesse caso, use **botão direito → Abrir** e confirme.

---

## Linux/macOS — scripts alternativos

Se preferir usar os scripts em vez dos executáveis nativos:

### Linux

```bash
chmod +x rodar-linux.sh
./rodar-linux.sh
```

### macOS

```bash
chmod +x rodar-mac.sh
./rodar-mac.sh
```

### Atalho Unix universal

Na raiz do projeto:

```bash
chmod +x rodar
./rodar
```

O arquivo `rodar` chama `scripts/rodar-unix.sh`.

---

## O que acontece na primeira execução

```text
Node.js 20.5+
      ↓
npm
      ↓
npm install
      ↓
SQLite / seed
      ↓
testes
      ↓
servidor
      ↓
/api/health
      ↓
navegador
```

As dependências são instaladas dentro de `backend/node_modules`.

Os logs ficam na pasta do projeto:

```text
volix-launcher.log
volix-server.log
```

Se alguma etapa falhar, consulte esses arquivos para identificar o erro.

---

## Execução manual

Caso queira executar o backend sem launcher:

```bash
cd backend
npm install
npm run seed
npm test
npm start
```

Depois acesse:

```text
http://localhost:3000
```

---

## Docker

Na raiz do projeto:

```bash
docker compose up
```

---

## Endereços

- Dashboard: `http://localhost:3000`
- Health check: `http://localhost:3000/api/health`

## Banco

O banco SQLite fica em:

```text
backend/data/volix.sqlite
```

## Catálogo de demonstração

O seed recria exatamente 1000 produtos locais e funcionais para a apresentação, sem depender da coleta pública da Shopee.

O modo padrão é `fixture/demonstração local`, portanto a execução inicial não depende de uma coleta HTTP pública da Shopee.
